import React from 'react'

const Delete = () => {
  return (
    <div>Delete</div>
  )
}

export default Delete