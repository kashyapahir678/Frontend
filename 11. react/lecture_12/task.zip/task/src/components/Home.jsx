import React from 'react'
import Breadcrumb from './Breadcrumb'


const Home = () => {
  return (
    <div>
      <Breadcrumb/>
    </div>
  )
}

export default Home