import './App.css'
import Exercise from './Exercise'

function App() {

  return (
    <>
       <Exercise/>
    </>
  )
}

export default App
